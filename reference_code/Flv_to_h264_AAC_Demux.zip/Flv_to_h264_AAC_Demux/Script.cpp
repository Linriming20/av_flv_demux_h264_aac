#include "Script.h"

double char2double(unsigned char * buf,unsigned int size)
{
	double scr = 0.0;
	unsigned char buf_1[8];
	unsigned char buf_2[8];
	memcpy(buf_1,buf,size);
	//��С������
	buf_2[0] = buf_1[7];
	buf_2[1] = buf_1[6];
	buf_2[2] = buf_1[5];
	buf_2[3] = buf_1[4];
	buf_2[4] = buf_1[3];
	buf_2[5] = buf_1[2];
	buf_2[6] = buf_1[1];
	buf_2[7] = buf_1[0];
	scr = *(double *)buf_2;
	return scr;
}

void double2char(unsigned char * buf,double val)
{
	*(double *)buf = val;
}

int AllocStruct_Script_Tag(Script_Tag ** scripttag)
{
	Script_Tag * scripttag_t = * scripttag;
	if ((scripttag_t = (Script_Tag *)calloc(1,sizeof(Script_Tag))) == NULL)
	{
		printf ("Error: Allocate Meory To AllocStruct_Script_Tag Buffer Failed ");
		return getchar();
	} 
	if ((scripttag_t->Data = (unsigned char * )calloc(ONE_SCRIPT_FRAME_SIZE,sizeof(unsigned char))) == NULL)
	{
		printf ("Error: Allocate Meory To scripttag_t->Data Buffer Failed ");
		return getchar();
	}
	* scripttag = scripttag_t;
	return 1;
}

int FreeStruct_Script_Tag(Script_Tag * scripttag)
{
	if (scripttag)
	{
		if (scripttag->Data)
		{
			free(scripttag->Data);
			scripttag->Data = NULL;
		}
		free(scripttag);
		scripttag = NULL;
	}
	return 1;
}

int ReadStruct_Script_Tag(unsigned char * Buf , unsigned int length ,Script_Tag * tag)
{
	int Script_Tag_pos = 0;
	int Arry_byte_length;
	unsigned char Arry_Name[MAX_ECMAARAY_NAME_LENGH];
	unsigned char Arry_InFomation;

	tag->Type = Buf[0];
	tag->DataSize = 
		Buf[1]  << 16 |
		Buf[2]  << 8  |
		Buf[3];
	tag->Timestamp = 
		Buf[4]  << 16 |
		Buf[5]  << 8  |
		Buf[6];
	tag->TimestampExtended = Buf[7];
	tag->StreamID = 
		Buf[8]  << 16 |
		Buf[9]  << 8  |
		Buf[10];
	Script_Tag_pos += 11;

	tag->Type_1 = Buf[Script_Tag_pos];
	Script_Tag_pos ++;
	if (tag->Type_1 == 0x02)
	{
		tag->StringLength = 
			Buf[Script_Tag_pos]   << 8 |
			Buf[Script_Tag_pos+1];
		Script_Tag_pos +=2;
		//������Ϣ���̶�Ϊ0x6F 0x6E 0x4D 0x65 0x74 0x64 0x44 0x61 0x74 0x61����ʾ�ַ���onMetaData

		Script_Tag_pos +=tag->StringLength;
	}
	tag->Type_1 = Buf[Script_Tag_pos];
	Script_Tag_pos ++;
	if (tag->Type_1 == 0x08)
	{
		tag->ECMAArrayLength =                   //��ʾ��������metadata array data ���ж���������
			Buf[Script_Tag_pos]     << 24 |
			Buf[Script_Tag_pos+1]   << 16 |
			Buf[Script_Tag_pos+2]   << 8  |
			Buf[Script_Tag_pos+3];
		Script_Tag_pos += 4;
	}

	for (int i = 0 ; i< tag->ECMAArrayLength ; i++)
	{
		//ǰ��2bytes��ʾ����N�������������ռ��bytes
		Arry_byte_length = 
			Buf[Script_Tag_pos]   << 8  |
			Buf[Script_Tag_pos+1];
		Script_Tag_pos +=2;

		memcpy(Arry_Name,Buf + Script_Tag_pos , Arry_byte_length);  //������������
		Script_Tag_pos += Arry_byte_length;

		Arry_InFomation = Buf[Script_Tag_pos];                      //������ȥ��1bytes��ʾ��������������Ϣ
		Script_Tag_pos ++;
		if (Arry_InFomation == 0x00) //����8bytes��ʾ�����Զ�Ӧ��floatֵ
		{
			Script_Tag_pos += 8;  
		}
		else if (Arry_InFomation == 0x01)//����1bytes��ʾboolean�������Ƿ�����ƵΪ01��ʾ�����С�����˼
		{
			Script_Tag_pos ++;
		}
		else if (Arry_InFomation == 0x02) //�����2bytes��ʾ�ַ������ȣ�Ȼ���ٸ���������ȴӺ�ߵ�bytes�ж�ȡ���ַ���
		{
			Script_Tag_pos += 
				Buf[Script_Tag_pos]  << 8 |
				Buf[Script_Tag_pos+1];
			Script_Tag_pos +=2;
		}
		else if (Arry_InFomation == 0x03) //������Ϣ�Ľ���
		{
			break;
		}
		else if (Arry_InFomation == 0x0A) //���ݱ�����ռ4bytes
		{
			Script_Tag_pos += 4;
		}
		else if (Arry_InFomation == 0x0B)//ռ10bytes����ʾ����
		{
			Script_Tag_pos += 10;
		}
		else
		{
			//δ����
		}
		if (strstr((char *)Arry_Name,"duration") != NULL)           
		{
			//Arry_InFomation == 0
			tag->duration= char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"width") != NULL)
		{
			//Arry_InFomation == 0;
			tag->width= char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"height") != NULL)
		{
			//Arry_InFomation == 0;
			tag->height = char2double(&Buf[Script_Tag_pos - 8],8);	
		}
		else if (strstr((char *)Arry_Name,"videodatarate") != NULL)
		{
			//Arry_InFomation == 0;
			tag->videodatarate = char2double(&Buf[Script_Tag_pos - 8],8);	
		}
		else if (strstr((char *)Arry_Name,"framerate") != NULL)
		{
			//Arry_InFomation == 0;
			tag->framerate = char2double(&Buf[Script_Tag_pos - 8],8);	
		}
		else if (strstr((char *)Arry_Name,"videocodecid") != NULL)
		{
			//Arry_InFomation == 0;
			tag->videocodecid = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"audiosamplerate") != NULL)
		{
			//Arry_InFomation == 0;
			tag->audiosamplerate = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"audiodatarate") != NULL)
		{
			//Arry_InFomation == 0;
			tag->audiodatarate = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"audiosamplesize") != NULL)
		{
			//Arry_InFomation == 0;
			tag->audiosamplesize = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"stereo") != NULL)
		{
			//Arry_InFomation == 1;
			tag->stereo = Buf[Script_Tag_pos -1];
		}
		else if (strstr((char *)Arry_Name,"audiocodecid") != NULL)
		{
			//Arry_InFomation == 0;
			tag->audiocodecid = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"filesize") != NULL)
		{
			//Arry_InFomation == 0;
			tag->filesize = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"lasttime") != NULL)
		{
			//Arry_InFomation == 0;
			tag->lasttimetamp = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else if (strstr((char *)Arry_Name,"lastkeyframetime") != NULL)
		{
			//Arry_InFomation == 0;
			tag->lastkeyframetimetamp = char2double(&Buf[Script_Tag_pos - 8],8);
		}
		else
		{
			//��ʱ��������
		}
	}
	//���data��������� ��ʲô��δ֪��
	memcpy(tag->Data,Buf + Script_Tag_pos,length - Script_Tag_pos );
	return 1;
}