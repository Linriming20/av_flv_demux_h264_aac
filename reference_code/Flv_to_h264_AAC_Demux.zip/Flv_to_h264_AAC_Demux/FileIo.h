#pragma once

#include "Information.h"

#define INPUTFLVFILENAME     "./FLV_STREAM/test.flv"
#define OUTPUTH264FILENAME   "./H264_STREAM/test.264"
#define OUTPUTAACFILENAME    "./AAC_STREAM/test.aac"

extern FILE * pVideo_H264_File;
extern FILE * pAudio_Aac_File;

extern FILE * pVideo_Audio_Flv_File;

FILE * OpenFile(char * FileName,char * OpenMode);                        //���ļ�
void   CloseFile(FILE * pFile);                                          //�ر��ļ�
int    ReadFile(FILE * pFile ,unsigned char * Buffer,int BufferSize);   //��ȡ����
int    WriteFile(FILE * pFile ,char * Buffer,int BufferSize);            //�ļ�д����

