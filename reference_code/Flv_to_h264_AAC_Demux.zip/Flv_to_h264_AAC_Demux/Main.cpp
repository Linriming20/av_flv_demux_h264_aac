#include "Demux.h"

int main()
{
	printf("--------�������п�ʼ----------\n");
	pVideo_Audio_Flv_File = OpenFile(INPUTFLVFILENAME,"rb");
	pVideo_H264_File = OpenFile(OUTPUTH264FILENAME,"wb");
	pAudio_Aac_File = OpenFile(OUTPUTAACFILENAME,"wb");

	AllocStruct();
	//////////////////////////////////////////////////////////////////////////
    ReadStruct();
	//////////////////////////////////////////////////////////////////////////
	FreeStruct();

	if (pVideo_H264_File)
	{
		CloseFile(pVideo_H264_File);
		pVideo_H264_File = NULL;
	}
	if (pAudio_Aac_File)
	{
		CloseFile(pAudio_Aac_File);
		pAudio_Aac_File = NULL;
	}
	if (pVideo_Audio_Flv_File)
	{
		CloseFile(pVideo_Audio_Flv_File);
		pVideo_Audio_Flv_File = NULL;
	}
	printf("--------�������н���----------\n");
	printf("-------�밴������˳�---------\n");
	return getchar();
}